/**
 * Popup Script - SmartShield
 * Onboarding flow + main app UI.
 * Scans by ROOT DOMAIN for speed; details lazy-loaded on accordion open.
 */

document.addEventListener("DOMContentLoaded", () => {
  // ─────────────────────────────────────────
  // ONBOARDING
  // ─────────────────────────────────────────
  const onboardingEl = document.getElementById("onboarding");
  const appEl = document.getElementById("app");

  const obSlides = [
    document.getElementById("ob-slide-1"),
    document.getElementById("ob-slide-2"),
    document.getElementById("ob-slide-3"),
  ];
  const obDots = [
    document.getElementById("dot-1"),
    document.getElementById("dot-2"),
    document.getElementById("dot-3"),
  ];
  const obNextBtn = document.getElementById("ob-next");
  const obSkipBtn = document.getElementById("ob-skip");
  const obSafeToggle = document.getElementById("ob-safe-mode");

  let currentSlide = 0; // 0-indexed

  function goToSlide(idx) {
    obSlides.forEach((s, i) => s.classList.toggle("active", i === idx));
    obDots.forEach((d, i) => d.classList.toggle("active", i === idx));
    currentSlide = idx;
    if (idx === obSlides.length - 1) {
      obNextBtn.textContent = "Get Started";
    } else {
      obNextBtn.textContent = "Continue";
    }
  }

  function showOnboarding() {
    onboardingEl.classList.remove("hidden");
    appEl.classList.add("hidden");
    goToSlide(0);
  }

  function showApp() {
    onboardingEl.classList.add("hidden");
    appEl.classList.remove("hidden");
    initMainApp();
  }

  async function completeOnboarding() {
    const safeModeVal = obSafeToggle ? obSafeToggle.checked : true;
    await chrome.storage.local.set({
      onboardingComplete: true,
      safeModeEnabled: safeModeVal,
    });
    showApp();
  }

  if (obNextBtn) {
    obNextBtn.addEventListener("click", () => {
      if (currentSlide < obSlides.length - 1) {
        goToSlide(currentSlide + 1);
      } else {
        completeOnboarding();
      }
    });
  }
  // Make dots clickable for navigation
  obDots.forEach((dot, idx) => {
    dot.addEventListener("click", () => goToSlide(idx));
  });
  if (obSkipBtn) {
    obSkipBtn.addEventListener("click", completeOnboarding);
  }

  // Boot: check if onboarding already done
  chrome.storage.local.get(["onboardingComplete"], (r) => {
    if (r.onboardingComplete) {
      showApp();
    } else {
      showOnboarding();
    }
  });

  // ─────────────────────────────────────────
  // MAIN APP
  // ─────────────────────────────────────────
  function initMainApp() {
    // ── DOM refs ──
    const safeModeToggle = document.getElementById("safe-mode-toggle");
    const statusCard = document.getElementById("status-card");
    const statusIcon = document.getElementById("status-icon");
    const statusTitle = document.getElementById("status-title");
    const statusDesc = document.getElementById("status-desc");
    const urlDisplay = document.getElementById("url-display");
    const urlText = document.getElementById("url-text");
    const metricsGrid = document.getElementById("metrics-grid");
    const riskScoreVal = document.getElementById("risk-score-val");
    const riskBarFill = document.getElementById("risk-bar-fill");
    const riskSub = document.getElementById("risk-sub");
    const confidenceScore = document.getElementById("confidence-score");
    const scanWarnings = document.getElementById("scan-warnings");
    const warningList = document.getElementById("warning-list");
    const detailsContainer = document.getElementById("details-container");

    const spContent = document.getElementById("sp-content");

    const alertModal = document.getElementById("alert-modal");
    const alertContent = document.getElementById("alert-content");
    const alertTitle = document.getElementById("alert-title");
    const alertMessage = document.getElementById("alert-message");
    const alertLeaveBtn = document.getElementById("alert-leave");
    const alertDismissBtn = document.getElementById("alert-dismiss");

    // ── State ──
    let currentRootDomain = null;
    let detailsFetched = false;
    let dismissedDomains = new Set();
    let lastScanResult = null;

    // Load previously dismissed domains from session storage
    chrome.storage.session.get(["dismissedAlerts"], (r) => {
      if (r.dismissedAlerts && Array.isArray(r.dismissedAlerts)) {
        dismissedDomains = new Set(r.dismissedAlerts);
      }
    });

    // ── Icons ──
    const Icons = {
      search: `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
      safe: `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>`,
      warn: `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
      danger: `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
      error: `<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
    };

    // ── Helper ──
    function getRootDomain(url) {
      try {
        const u = new URL(url);
        return u.protocol + "//" + u.hostname;
      } catch {
        return url;
      }
    }

    // ── Safe Mode toggle init ──
    chrome.storage.local.get(["safeModeEnabled"], (r) => {
      const enabled =
        r.safeModeEnabled !== undefined ? r.safeModeEnabled : true;
      if (safeModeToggle) safeModeToggle.checked = enabled;
    });
    if (safeModeToggle) {
      safeModeToggle.addEventListener("change", async (e) => {
        const isEnabled = e.target.checked;
        await chrome.storage.local.set({ safeModeEnabled: isEnabled });
        chrome.runtime.sendMessage({
          action: "safeModeChanged",
          enabled: isEnabled,
        });
      });
    }

    // ── Show Badge on Page button ──
    const locateBadgeBtn = document.getElementById("locate-badge-btn");
    if (locateBadgeBtn) {
      locateBadgeBtn.addEventListener("click", async () => {
        const tabs = await chrome.tabs.query({
          active: true,
          currentWindow: true,
        });
        if (!tabs[0]) return;
        // Send message to content script to flash / recreate the badge
        chrome.tabs
          .sendMessage(tabs[0].id, { action: "locateBadge" })
          .catch(() => {});
        // Brief visual confirmation in the popup
        const origHTML = locateBadgeBtn.innerHTML;
        locateBadgeBtn.classList.add("done");
        locateBadgeBtn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Badge shown!`;
        setTimeout(() => {
          locateBadgeBtn.classList.remove("done");
          locateBadgeBtn.innerHTML = origHTML;
        }, 2000);
      });
    }
    function dismissAlert() {
      if (alertModal) alertModal.classList.add("hidden");
      if (currentRootDomain) {
        dismissedDomains.add(currentRootDomain);
        chrome.storage.session.set({ dismissedAlerts: [...dismissedDomains] });
      }
    }

    if (alertLeaveBtn) {
      alertLeaveBtn.addEventListener("click", async () => {
        dismissAlert();
        const tabs = await chrome.tabs.query({
          active: true,
          currentWindow: true,
        });
        if (tabs[0])
          chrome.tabs.update(tabs[0].id, { url: "https://www.google.com" });
      });
    }
    if (alertDismissBtn) {
      alertDismissBtn.addEventListener("click", () => dismissAlert());
    }

    // ── Lazy-load detail data ──
    function lazyLoadDetails() {
      if (detailsFetched || !currentRootDomain) return;
      detailsFetched = true;
      chrome.runtime.sendMessage(
        { action: "getDetails", url: currentRootDomain },
        (details) => {
          if (chrome.runtime.lastError || !details) return;
          populateDetails(details);
        },
      );
    }

    // ── Scan current page ──
    async function scanCurrentPage() {
      // Reset UI to scanning state
      if (statusIcon) {
        statusIcon.className = "status-ring scanning";
        statusIcon.innerHTML = Icons.search;
      }
      if (statusCard) statusCard.className = "status-card";
      if (statusTitle) {
        statusTitle.textContent = "Scanning…";
        statusTitle.removeAttribute("style");
      }
      if (statusDesc) {
        statusDesc.textContent =
          "Analyzing domain reputation and page content…";
      }
      if (scanWarnings) scanWarnings.classList.add("hidden");
      if (detailsContainer) detailsContainer.classList.add("hidden");
      if (metricsGrid) metricsGrid.classList.add("hidden");

      try {
        const tabs = await chrome.tabs.query({
          active: true,
          currentWindow: true,
        });
        const tab = tabs[0];
        if (!tab || !tab.url) {
          displayError("Unable to access the current page URL.");
          return;
        }

        currentRootDomain = getRootDomain(tab.url);
        displayURL(tab.url);

        chrome.runtime.sendMessage(
          { action: "checkURL", url: currentRootDomain },
          (result) => {
            if (statusIcon) statusIcon.classList.remove("scanning");
            if (chrome.runtime.lastError) {
              displayError("Scan service temporarily unavailable. Try again.");
              return;
            }
            if (!result) {
              displayError("Unable to complete scan. Check your connection.");
              return;
            }
            displayResult(result);
          },
        );
      } catch {
        if (statusIcon) statusIcon.classList.remove("scanning");
        displayError("An unexpected error occurred during the scan.");
      }
    }

    // ── Display URL chip ──
    function displayURL(url) {
      try {
        const u = new URL(url);
        if (urlText)
          urlText.textContent =
            u.hostname + (u.pathname !== "/" ? u.pathname : "");
        if (urlDisplay) urlDisplay.classList.remove("hidden");
      } catch {
        /* ignore */
      }
    }

    // ── Render scan results ──
    function displayResult(result) {
      if (!result) return;
      const riskScore = result.riskScore || 0;
      const confidence = result.confidence || 0;

      // Metrics row
      if (metricsGrid) metricsGrid.classList.remove("hidden");
      if (riskScoreVal) riskScoreVal.textContent = riskScore;
      if (riskBarFill) {
        setTimeout(() => {
          riskBarFill.style.width = `${riskScore}%`;
        }, 50);
        if (riskScore >= 70) riskBarFill.style.background = "var(--danger)";
        else if (riskScore >= 40)
          riskBarFill.style.background = "var(--warning)";
        else riskBarFill.style.background = "var(--success)";
      }
      if (riskSub) {
        if (riskScore >= 70) riskSub.textContent = "High Risk";
        else if (riskScore >= 40) riskSub.textContent = "Moderate Risk";
        else riskSub.textContent = "Low Risk";
      }
      if (confidenceScore) {
        confidenceScore.textContent = confidence
          ? `${Math.round(confidence)}%`
          : "N/A";
      }

      // Status card
      if (result.isSuspicious) {
        if (result.riskLevel === "high" || riskScore >= 70) {
          if (statusIcon) {
            statusIcon.className = "status-ring danger";
            statusIcon.innerHTML = Icons.danger;
          }
          if (statusCard) statusCard.className = "status-card danger";
          if (statusTitle) {
            statusTitle.textContent = "High Risk Detected";
            statusTitle.style.color = "var(--danger)";
          }
          if (statusDesc)
            statusDesc.textContent =
              "Strong signs of phishing. Do not enter personal information.";
          showAlertModal(
            "Phishing Website Detected",
            "This site has been flagged as a phishing attempt. Do not enter passwords, payment info, or personal data.",
            "danger",
          );
        } else {
          if (statusIcon) {
            statusIcon.className = "status-ring warn";
            statusIcon.innerHTML = Icons.warn;
          }
          if (statusCard) statusCard.className = "status-card warn";
          if (statusTitle) {
            statusTitle.textContent = "Suspicious Activity";
            statusTitle.style.color = "var(--warning)";
          }
          if (statusDesc)
            statusDesc.textContent =
              "This site has suspicious characteristics. Proceed with caution.";
          showAlertModal(
            "Suspicious Website",
            "This site shows suspicious patterns. Avoid entering sensitive information.",
            "warn",
          );
        }
        if (result.warnings && result.warnings.length > 0) {
          if (scanWarnings) scanWarnings.classList.remove("hidden");
          if (warningList)
            warningList.innerHTML = result.warnings
              .map((w) => `<div>• ${w}</div>`)
              .join("");
        }
      } else {
        if (statusIcon) {
          statusIcon.className = "status-ring safe";
          statusIcon.innerHTML = Icons.safe;
        }
        if (statusCard) statusCard.className = "status-card safe";
        if (statusTitle) {
          statusTitle.textContent = "Site is Safe";
          statusTitle.style.color = "var(--success)";
        }
        if (statusDesc)
          statusDesc.textContent =
            "No threats detected. This website appears legitimate.";
        if (scanWarnings) scanWarnings.classList.add("hidden");
      }

      // Show details accordion
      if (detailsContainer) detailsContainer.classList.remove("hidden");
      if (result.details) {
        lastScanResult = result;
        detailsFetched = true;
        populateDetails(result.details);
      } else {
        lazyLoadDetails();
      }
    }

    // ── Bot Explainer ──
    function renderMarkdown(text) {
      // Escape HTML then convert **bold** to <strong>
      return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    }

    function generateBotMessages(scan, details) {
      const msgs = [];
      const riskScore = (scan && scan.riskScore) || 0;
      const isSuspicious = scan && scan.isSuspicious;
      const status = riskScore >= 70 ? "Dangerous" : riskScore >= 40 ? "Warning" : "Safe";

      // 1. Verdict
      if (status === "Dangerous") {
        msgs.push({ icon: "🚨", label: "Verdict", accent: "red",
          text: `**Don't visit this site.** Our AI flagged this as a high-risk website with a threat score of **${riskScore}/100**. This level means it's very likely dangerous.` });
      } else if (status === "Warning") {
        msgs.push({ icon: "⚠️", label: "Verdict", accent: "yellow",
          text: `**Be careful here.** This site scored **${riskScore}/100**, which puts it in the suspicious range. It hasn't been confirmed as dangerous, but something's off.` });
      } else {
        msgs.push({ icon: "✅", label: "Verdict", accent: "green",
          text: `**This site looks safe.** It scored **${riskScore}/100** — low risk. Our AI didn't find anything alarming here, so you can browse with confidence.` });
      }

      // 2. Score meaning
      if (riskScore >= 70) {
        msgs.push({ icon: "📊", label: "Risk Level", accent: "red",
          text: `A score above **70** is our red-alert zone. Only a small fraction of sites score this high, and most turn out to be scams or phishing pages.` });
      } else if (riskScore >= 40) {
        msgs.push({ icon: "📊", label: "Risk Level", accent: "yellow",
          text: `Scores between **40–70** signal caution. The site has some suspicious traits — like a new domain or unusual patterns — but isn't confirmed malicious.` });
      } else {
        msgs.push({ icon: "📊", label: "Risk Level", accent: "green",
          text: `Scores below **40** are in the safe zone. Most trusted websites land here. This site passed our key checks without raising flags.` });
      }

      // 3. HTTP warning
      if (scan && scan.url && scan.url.toLowerCase().startsWith("http://")) {
        msgs.push({ icon: "🔓", label: "Connection", accent: "yellow",
          text: `This page is loaded over **HTTP** (not HTTPS). That means your data is not encrypted — anyone on the same network can potentially see what you're doing here.` });
      }

      // 4. WHOIS domain info
      if (details && details.whois) {
        const w = details.whois;
        const regDate = w.creationDate || w.creation_date || null;
        const registrar = w.registrar || null;
        if (regDate || registrar) {
          let ageText = "";
          if (regDate) {
            const created = new Date(regDate);
            const ageMonths = Math.floor((Date.now() - created.getTime()) / (1000 * 60 * 60 * 24 * 30));
            if (ageMonths < 3) {
              ageText = `This domain is only **${ageMonths} month${ageMonths !== 1 ? "s" : ""} old** — brand-new domains are a major red flag for scams.`;
            } else if (ageMonths < 12) {
              ageText = `This domain is about **${ageMonths} months old**. Newer domains carry more risk than established ones.`;
            } else {
              const years = Math.floor(ageMonths / 12);
              ageText = `This domain has been around for **${years} year${years !== 1 ? "s" : ""}**, which is a good sign of legitimacy.`;
            }
          }
          const regText = registrar ? ` Registered through **${registrar}**.` : "";
          msgs.push({ icon: "🌐", label: "Domain Info", accent: status === "Dangerous" ? "red" : status === "Warning" ? "yellow" : "blue",
            text: ageText + regText });
        }
      }

      // 5. SSL
      if (details && details.ssl) {
        const s = details.ssl;
        if (s.error) {
          const sslAccent = status === "Dangerous" ? "red" : "yellow";
          msgs.push({ icon: "🔒", label: "SSL Certificate", accent: sslAccent,
            text: `**No valid SSL certificate** was found. Legitimate sites almost always have one. ${status === "Dangerous" ? "Scammers often skip SSL or let it expire." : "This is a reason to be cautious."}` });
        } else {
          const issuer = s.issuer || "unknown issuer";
          msgs.push({ icon: "🔒", label: "SSL Certificate", accent: "green",
            text: `The site has a **valid SSL certificate** issued by **${issuer}**. Your connection is encrypted, though this alone doesn't make a site trustworthy.` });
        }
      }

      // 6. Final advice
      if (status === "Dangerous") {
        msgs.push({ icon: "🛑", label: "What To Do", accent: "red",
          text: `**Don't enter any personal information** — no passwords, payment details, or personal data. Close this tab and report it if you can.` });
      } else if (status === "Warning") {
        msgs.push({ icon: "💡", label: "What To Do", accent: "yellow",
          text: `**Stay cautious.** Avoid logging in or submitting forms until you're sure this site is legitimate. Look for trust signals like official branding.` });
      } else {
        msgs.push({ icon: "👍", label: "What To Do", accent: "green",
          text: `**Safe to use.** Feel free to browse normally. As always, stay alert for anything that seems out of place.` });
      }

      return msgs;
    }

    // ── Populate bot explainer ──
    function populateDetails(details) {
      if (!spContent) return;
      spContent.innerHTML = "";

      const scan = lastScanResult;
      const messages = generateBotMessages(scan, details);

      const container = document.createElement("div");
      container.className = "sp-bot-container";

      messages.forEach((msg, idx) => {
        const card = document.createElement("div");
        card.className = `sp-bot-message sp-bot-accent-${msg.accent}`;
        card.style.animationDelay = idx === 0 ? "0s" : `${400 + (idx - 1) * 700}ms`;

        const header = document.createElement("div");
        header.className = "sp-bot-header";

        const iconEl = document.createElement("span");
        iconEl.className = "sp-bot-icon";
        iconEl.textContent = msg.icon;

        const labelEl = document.createElement("span");
        labelEl.textContent = msg.label;

        header.appendChild(iconEl);
        header.appendChild(labelEl);

        const content = document.createElement("div");
        content.className = "sp-bot-content";
        content.innerHTML = renderMarkdown(msg.text);

        card.appendChild(header);
        card.appendChild(content);
        container.appendChild(card);
      });

      spContent.appendChild(container);
    }

    // ── Error state ──
    function displayError(message) {
      if (statusIcon) {
        statusIcon.className = "status-ring";
        statusIcon.innerHTML = Icons.error;
      }
      if (statusCard) statusCard.className = "status-card";
      if (statusTitle) {
        statusTitle.textContent = "Scan Error";
        statusTitle.style.color = "var(--danger)";
      }
      if (statusDesc) statusDesc.textContent = message;
      if (scanWarnings) scanWarnings.classList.add("hidden");
      if (detailsContainer) detailsContainer.classList.add("hidden");
      if (metricsGrid) metricsGrid.classList.add("hidden");
    }

    // ── Alert modal ──
    function showAlertModal(title, message, type = "danger") {
      if (!alertModal) return;
      // Don't re-show if user already dismissed for this domain
      if (currentRootDomain && dismissedDomains.has(currentRootDomain)) return;
      if (alertTitle) alertTitle.textContent = title;
      if (alertMessage) alertMessage.textContent = message;
      if (alertContent) alertContent.className = `modal-box ${type}`;
      alertModal.classList.remove("hidden");
    }

    // ── Kick off scan ──
    scanCurrentPage();
  } // end initMainApp
});
